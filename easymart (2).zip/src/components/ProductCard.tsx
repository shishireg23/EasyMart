import { motion } from 'motion/react';
import { ShoppingCart, Eye, Star } from 'lucide-react';
import { Product } from '../types';
import { formatPrice } from '../lib/utils';
import { useCart } from '../context/CartContext';
import { Link } from 'react-router-dom';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ y: -5 }}
      className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all border border-gray-100"
    >
      <div className="relative aspect-square overflow-hidden bg-gray-50">
        <Link to={`/product/${product.id}`}>
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            referrerPolicy="no-referrer"
          />
        </Link>
        
        {/* Badges */}
        <div className="absolute top-4 left-4 flex flex-col gap-2">
            <span className="px-3 py-1 bg-white/90 backdrop-blur-sm text-[10px] font-bold uppercase tracking-wider rounded-full shadow-sm text-gray-900 border border-gray-100">
               {product.category}
            </span>
            {product.stock < 10 && (
                <span className="px-3 py-1 bg-orange-500 text-[10px] font-bold uppercase tracking-wider rounded-full shadow-sm text-white">
                  Low Stock
                </span>
            )}
        </div>

        {/* Hover Actions */}
        <div className="absolute bottom-4 left-4 right-4 flex gap-2 translate-y-20 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all">
             <button
               onClick={() => addToCart(product)}
               className="flex-1 bg-gray-900 text-white py-2.5 rounded-lg text-sm font-bold flex items-center justify-center gap-2 hover:bg-orange-600 transition-colors"
             >
                <ShoppingCart className="w-4 h-4" />
                Add to Cart
             </button>
             <Link
               to={`/product/${product.id}`}
               className="w-12 bg-white text-gray-900 rounded-lg flex items-center justify-center hover:bg-gray-100 transition-colors shadow-lg shadow-black/5"
             >
                <Eye className="w-4 h-4" />
             </Link>
        </div>
      </div>

      <div className="p-5">
        <div className="flex items-center gap-1 mb-2">
            {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-3 h-3 fill-orange-400 text-orange-400" />
            ))}
            <span className="text-[10px] font-medium text-gray-400 ml-1">(4.8)</span>
        </div>
        <Link to={`/product/${product.id}`}>
          <h3 className="text-sm font-bold text-gray-900 mb-1 line-clamp-1 group-hover:text-orange-600 transition-colors">
            {product.name}
          </h3>
        </Link>
        <p className="text-xs text-gray-500 mb-4 line-clamp-1">
          {product.description}
        </p>
        <div className="flex items-center justify-between">
          <span className="text-lg font-black text-gray-900">
            {formatPrice(product.price)}
          </span>
          {product.price > 150 && (
              <span className="text-[10px] text-green-600 font-bold bg-green-50 px-2 py-0.5 rounded">Free Shipping</span>
          )}
        </div>
      </div>
    </motion.div>
  );
}
