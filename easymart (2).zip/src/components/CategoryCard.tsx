import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { Category } from '../types';

interface CategoryCardProps {
  name: Category;
  image: string;
  description: string;
  itemCount: number;
}

export default function CategoryCard({ name, image, description, itemCount }: CategoryCardProps) {
  return (
    <Link to={`/category/${name}`} className="group relative h-80 rounded-3xl overflow-hidden block">
      <img
        src={image}
        alt={name}
        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        referrerPolicy="no-referrer"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
      
      <div className="absolute bottom-0 left-0 p-8 w-full">
        <div className="flex items-center justify-between mb-2">
            <span className="text-orange-400 text-xs font-bold uppercase tracking-widest leading-none">
              {itemCount} Items
            </span>
            <div className="w-8 h-8 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center translate-x-4 opacity-0 group-hover:translate-x-0 group-hover:opacity-100 transition-all">
                <ArrowRight className="text-white w-4 h-4" />
            </div>
        </div>
        <h3 className="text-2xl font-bold text-white mb-2">{name}</h3>
        <p className="text-gray-300 text-sm leading-relaxed opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all">
          {description}
        </p>
      </div>
    </Link>
  );
}
