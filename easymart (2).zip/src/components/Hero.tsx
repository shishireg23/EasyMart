import { motion } from 'motion/react';
import { ArrowRight, ShoppingBag } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Hero() {
  return (
    <section className="relative h-[80vh] overflow-hidden bg-gray-100">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1556906781-9a412961c28c?auto=format&fit=crop&q=80&w=1920"
          alt="Hero"
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/40 to-transparent" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-center">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-xl text-white"
        >
          <motion.span
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="inline-block px-3 py-1 mb-6 text-xs font-bold tracking-widest text-orange-400 uppercase bg-orange-400/10 rounded-full border border-orange-400/20"
          >
            Spring Summer 2026
          </motion.span>
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            Elevate Your <span className="text-orange-500">Everyday</span> Gear.
          </h1>
          <p className="text-lg text-gray-300 mb-10 leading-relaxed max-w-lg">
            Discover the perfect blend of performance sneakers, cutting-edge electronics, and essential fashion at EasyMart.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link
              to="/category/Sneakers"
              className="px-8 py-4 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl flex items-center justify-center transition-all group"
            >
              Shop Sneakers
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link
              to="/category/Electronics"
              className="px-8 py-4 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl flex items-center justify-center backdrop-blur-sm transition-all border border-white/30"
            >
              Browse Electronics
            </Link>
          </div>
        </motion.div>
      </div>

      {/* Decorative elements */}
      <motion.div
        animate={{
          y: [0, 20, 0],
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute bottom-10 right-10 hidden lg:block"
      >
        <div className="p-4 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl flex items-center space-x-4">
          <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center shadow-lg shadow-orange-500/50">
             <ShoppingBag className="text-white w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-orange-300 font-bold uppercase tracking-wider">Fast Shipping</p>
            <p className="text-white font-semibold">Free on orders $100+</p>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
