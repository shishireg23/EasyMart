import { useParams, Link } from 'react-router-dom';
import { products } from '../data/products';
import { useState, useEffect } from 'react';
import { useCart } from '../context/CartContext';
import { ShoppingCart, Star, Shield, ArrowLeft, Heart, Share2, Plus, Minus, Truck, RefreshCw } from 'lucide-react';
import { formatPrice } from '../lib/utils';
import { motion } from 'motion/react';
import ProductCard from '../components/ProductCard';

export default function ProductDetail() {
  const { id } = useParams();
  const product = products.find((p) => p.id === id);
  const [quantity, setQuantity] = useState(1);
  const { addToCart } = useCart();

  useEffect(() => {
     window.scrollTo(0, 0);
  }, [id]);

  if (!product) {
    return (
      <div className="h-[60vh] flex flex-col items-center justify-center">
        <h2 className="text-2xl font-bold mb-4">Product not found</h2>
        <Link to="/" className="text-orange-600 font-bold hover:underline">Back to Shop</Link>
      </div>
    );
  }

  const relatedProducts = products
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  return (
    <main className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Link to="/" className="inline-flex items-center text-sm font-medium text-gray-500 hover:text-orange-600 mb-8 transition-colors">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Catalog
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          {/* Image Gallery */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-4"
          >
            <div className="aspect-square rounded-3xl overflow-hidden bg-gray-50 border border-gray-100">
                <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                />
            </div>
            <div className="grid grid-cols-4 gap-4">
                {[product.image, product.image, product.image, product.image].map((img, idx) => (
                    <div key={idx} className="aspect-square rounded-xl overflow-hidden bg-gray-50 border border-gray-100 cursor-pointer hover:border-orange-500 transition-all opacity-60 hover:opacity-100">
                        <img src={img} alt="Thumb" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </div>
                ))}
            </div>
          </motion.div>

          {/* Product Info */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex flex-col h-full"
          >
            <div className="mb-6">
                <span className="px-3 py-1 bg-orange-50 text-orange-600 text-xs font-black uppercase tracking-widest rounded-full">
                    {product.category}
                </span>
            </div>
            
            <h1 className="text-4xl font-black text-gray-900 mb-4">{product.name}</h1>
            
            <div className="flex items-center gap-4 mb-8">
                <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                        <Star key={i} className={`w-4 h-4 ${i < 4 ? 'fill-orange-400 text-orange-400' : 'text-gray-300'}`} />
                    ))}
                    <span className="text-sm font-bold text-gray-900 ml-2">4.2 (1.5k Reviews)</span>
                </div>
                <div className="h-4 w-px bg-gray-200" />
                <span className="text-sm font-bold text-green-600">In Stock ({product.stock} items)</span>
            </div>

            <p className="text-4xl font-black text-gray-900 mb-8">{formatPrice(product.price)}</p>
            
            <p className="text-gray-600 leading-relaxed text-lg mb-10">
              {product.description}
            </p>

            {/* Features */}
            {product.features && (
                <div className="mb-10 space-y-3">
                    {product.features.map((feature, idx) => (
                        <div key={idx} className="flex items-center text-sm text-gray-600">
                            <div className="w-1.5 h-1.5 bg-orange-500 rounded-full mr-3" />
                            {feature}
                        </div>
                    ))}
                </div>
            )}

            {/* Actions */}
            <div className="space-y-6 mt-auto">
                <div className="flex flex-wrap gap-4">
                    <div className="flex items-center bg-gray-100 rounded-xl p-1 h-14 w-32">
                        <button 
                          onClick={() => setQuantity(q => Math.max(1, q - 1))}
                          className="flex-1 flex justify-center text-gray-500 hover:text-orange-600"
                        >
                            <Minus className="w-4 h-4" />
                        </button>
                        <span className="w-8 text-center font-bold">{quantity}</span>
                        <button 
                          onClick={() => setQuantity(q => q + 1)}
                          className="flex-1 flex justify-center text-gray-500 hover:text-orange-600"
                        >
                            <Plus className="w-4 h-4" />
                        </button>
                    </div>
                    <button
                        onClick={() => addToCart({ ...product })}
                        className="flex-1 h-14 bg-gray-900 text-white rounded-xl flex items-center justify-center gap-3 font-bold hover:bg-orange-600 transition-all shadow-lg shadow-black/5"
                    >
                        <ShoppingCart className="w-5 h-5" />
                        Add to Cart
                    </button>
                    <button className="w-14 h-14 border border-gray-200 rounded-xl flex items-center justify-center hover:bg-red-50 hover:text-red-500 transition-all text-gray-400">
                        <Heart className="w-5 h-5" />
                    </button>
                    <button className="w-14 h-14 border border-gray-200 rounded-xl flex items-center justify-center hover:bg-gray-50 transition-all text-gray-400">
                        <Share2 className="w-5 h-5" />
                    </button>
                </div>

                {/* Badges */}
                <div className="grid grid-cols-2 gap-4 pt-8 border-t border-gray-100">
                    <div className="flex items-center text-xs text-gray-500">
                        <Truck className="w-4 h-4 mr-2 text-orange-500" />
                        Free Shipping Worldwide
                    </div>
                    <div className="flex items-center text-xs text-gray-500">
                        <RefreshCw className="w-4 h-4 mr-2 text-orange-500" />
                        30-Day Easy Returns
                    </div>
                    <div className="flex items-center text-xs text-gray-500">
                        <Shield className="w-4 h-4 mr-2 text-orange-500" />
                        Secure Payment Warranty
                    </div>
                </div>
            </div>
          </motion.div>
        </div>

        {/* Related Products */}
        <section className="mt-32">
            <h2 className="text-2xl font-bold mb-12">You Might Also Like</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                {relatedProducts.map(p => (
                  <div key={p.id}>
                    <ProductCard product={p} />
                  </div>
                ))}
            </div>
        </section>
      </div>
    </main>
  );
}
