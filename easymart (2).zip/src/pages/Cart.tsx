import { useCart } from '../context/CartContext';
import { formatPrice } from '../lib/utils';
import { Minus, Plus, Trash2, ArrowLeft, ShoppingBag, CreditCard, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';

export default function Cart() {
  const { cart, removeFromCart, updateQuantity, totalPrice } = useCart();

  if (cart.length === 0) {
    return (
      <main className="min-h-[70vh] flex flex-col items-center justify-center bg-gray-50 px-4">
        <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mb-6"
        >
            <ShoppingBag className="w-10 h-10 text-gray-400" />
        </motion.div>
        <h2 className="text-2xl font-bold mb-2">Your cart is empty</h2>
        <p className="text-gray-500 mb-8 max-w-xs text-center">Looks like you haven't added anything to your cart yet. Gear up today!</p>
        <Link
          to="/"
          className="px-8 py-3 bg-gray-900 text-white rounded-xl font-bold hover:bg-orange-600 transition-all flex items-center"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Start Shopping
        </Link>
      </main>
    );
  }

  return (
    <main className="py-12 md:py-24 bg-gray-50/50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-8">
            <Link to="/" className="hover:text-orange-600 transition-colors">Home</Link>
            <ChevronRight className="w-4 h-4" />
            <span className="font-bold text-gray-900">Shopping Cart</span>
        </div>

        <h1 className="text-3xl md:text-4xl font-black text-gray-900 mb-12">Your Shopping Bag</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-start">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            <AnimatePresence>
                {cart.map((item) => (
                    <motion.div
                        key={item.id}
                        layout
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, x: -10 }}
                        className="bg-white p-6 rounded-2xl flex flex-col sm:flex-row gap-6 border border-gray-100 shadow-sm"
                    >
                        <div className="w-full sm:w-32 h-32 rounded-xl overflow-hidden bg-gray-50 border border-gray-100 flex-shrink-0">
                            <img src={item.image} alt={item.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        </div>
                        <div className="flex-1 flex flex-col justify-between">
                            <div className="flex justify-between items-start">
                                <div>
                                    <h3 className="font-bold text-gray-900 text-lg mb-1">{item.name}</h3>
                                    <span className="text-xs font-bold text-orange-600 uppercase tracking-wider">{item.category}</span>
                                </div>
                                <button
                                    onClick={() => removeFromCart(item.id)}
                                    className="p-2 text-gray-400 hover:text-red-500 transition-all hover:bg-red-50 rounded-lg"
                                >
                                    <Trash2 className="w-5 h-5" />
                                </button>
                            </div>
                            <div className="flex justify-between items-end mt-4">
                                <div className="flex items-center bg-gray-100 rounded-lg p-1">
                                    <button
                                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                        className="w-8 h-8 flex items-center justify-center text-gray-500 hover:text-orange-600 transition-colors"
                                    >
                                        <Minus className="w-4 h-4" />
                                    </button>
                                    <span className="w-10 text-center font-bold text-sm">{item.quantity}</span>
                                    <button
                                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                        className="w-8 h-8 flex items-center justify-center text-gray-500 hover:text-orange-600 transition-colors"
                                    >
                                        <Plus className="w-4 h-4" />
                                    </button>
                                </div>
                                <p className="font-black text-xl text-gray-900">{formatPrice(item.price * item.quantity)}</p>
                            </div>
                        </div>
                    </motion.div>
                ))}
            </AnimatePresence>
          </div>

          {/* Summary */}
          <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-xl sticky top-24">
            <h2 className="text-2xl font-black mb-8">Order Summary</h2>
            <div className="space-y-4 mb-8">
              <div className="flex justify-between text-gray-500 text-sm">
                <span>Subtotal</span>
                <span className="font-bold text-gray-900">{formatPrice(totalPrice)}</span>
              </div>
              <div className="flex justify-between text-gray-500 text-sm">
                <span>Shipping</span>
                <span className="font-bold text-green-600">FREE</span>
              </div>
              <div className="flex justify-between text-gray-500 text-sm">
                <span>Estimated Tax (8%)</span>
                <span className="font-bold text-gray-900">{formatPrice(totalPrice * 0.08)}</span>
              </div>
              <div className="border-t border-gray-100 pt-4 flex justify-between">
                <span className="font-extrabold text-xl">Total</span>
                <span className="font-black text-2xl text-orange-600">{formatPrice(totalPrice * 1.08)}</span>
              </div>
            </div>

            <Link
              to="/checkout"
              className="w-full py-4 bg-gray-900 text-white rounded-xl font-bold flex items-center justify-center gap-3 hover:bg-orange-600 transition-all shadow-lg shadow-black/5"
            >
              <CreditCard className="w-5 h-5" />
              Proceed to Checkout
            </Link>

            <div className="mt-8 pt-8 border-t border-gray-100 space-y-4">
                <div className="flex items-center gap-3 text-xs text-gray-400">
                    <span className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center">🛡️</span>
                    Encrypted and secure payments
                </div>
                <div className="flex items-center gap-3 text-xs text-gray-400">
                    <span className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center">📦</span>
                    Real-time order tracking available
                </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
