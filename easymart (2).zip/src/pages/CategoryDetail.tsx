import { useParams, Link } from 'react-router-dom';
import { products } from '../data/products';
import ProductCard from '../components/ProductCard';
import { ArrowLeft, Filter, SlidersHorizontal } from 'lucide-react';
import { motion } from 'motion/react';
import { Category } from '../types';

export default function CategoryDetail() {
  const { name } = useParams();
  const categoryProducts = products.filter((p) => p.category === name);

  const categoryInfo = {
    Sneakers: {
      title: 'Premium Footwear',
      description: 'From high-performance running shoes to limited-edition street style.',
      banner: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=1920'
    },
    Electronics: {
      title: 'Next-Gen Technology',
      description: 'Cutting-edge gadgets and essential electronics for the modern world.',
      banner: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80&w=1920'
    },
    Fashion: {
      title: 'Modern Essentials',
      description: 'Timeless style and contemporary fashion curated for your wardrobe.',
      banner: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=1920'
    }
  }[name as Category];

  return (
    <main className="pb-24">
      {/* Category Banner */}
      <section className="relative h-[40vh] overflow-hidden">
        <img
          src={categoryInfo?.banner}
          alt={name}
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-black/50 backdrop-blur-[2px]" />
        <div className="absolute inset-0 flex flex-col justify-center items-center text-center px-4">
           <Link to="/" className="fixed top-24 left-8 z-10 px-4 py-2 bg-white/10 backdrop-blur-md rounded-full text-white text-xs font-bold flex items-center hover:bg-white/20 transition-all border border-white/20 hidden lg:flex">
              <ArrowLeft className="w-3 h-3 mr-2" />
              Back
           </Link>
           <motion.h1 
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
             className="text-4xl md:text-6xl font-black text-white mb-4"
           >
             {categoryInfo?.title}
           </motion.h1>
           <motion.p 
             initial={{ opacity: 0 }}
             animate={{ opacity: 1 }}
             transition={{ delay: 0.2 }}
             className="text-gray-300 max-w-xl text-lg font-medium"
           >
             {categoryInfo?.description}
           </motion.p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        {/* Filters Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-12 py-6 border-b border-gray-100">
           <div className="flex items-center gap-4">
              <button className="flex items-center gap-2 px-4 py-2 bg-gray-900 text-white rounded-lg text-sm font-bold">
                 <Filter className="w-4 h-4" />
                 Filter
              </button>
              <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 text-gray-600 rounded-lg text-sm font-bold hover:bg-gray-50">
                 <SlidersHorizontal className="w-4 h-4" />
                 Sort
              </button>
           </div>
           <p className="text-gray-400 text-sm font-medium">
              Showing <span className="text-gray-900 font-bold">{categoryProducts.length}</span> outcomes
           </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {categoryProducts.map((product) => (
            <div key={product.id}>
              <ProductCard product={product} />
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
