import Hero from '../components/Hero';
import { products } from '../data/products';
import ProductCard from '../components/ProductCard';
import CategoryCard from '../components/CategoryCard';
import { motion } from 'motion/react';
import { Sparkles, TrendingUp, ShieldCheck, Truck } from 'lucide-react';

export default function Home() {
  const featuredProducts = products.filter(p => ['s1', 's2', 'e1', 'e2', 's3', 'f1', 's7', 's8'].includes(p.id));

  const categories = [
    {
      name: 'Sneakers' as const,
      image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800',
      description: 'Performance running shoes and premium street style.',
      itemCount: products.filter(p => p.category === 'Sneakers').length
    },
    {
      name: 'Electronics' as const,
      image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80&w=800',
      description: 'Cutting-edge tech for your digital lifestyle.',
      itemCount: products.filter(p => p.category === 'Electronics').length
    },
    {
      name: 'Fashion' as const,
      image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=800',
      description: 'Modern essentials and standout wardrobe pieces.',
      itemCount: products.filter(p => p.category === 'Fashion').length
    }
  ];

  return (
    <main>
      <Hero />

      {/* Features Bar */}
      <section className="py-12 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                {[
                    { icon: <Truck className="w-5 h-5" />, title: "Free Shipping", desc: "On orders over $100" },
                    { icon: <ShieldCheck className="w-5 h-5" />, title: "Secure Payment", desc: "100% protected checkout" },
                    { icon: <TrendingUp className="w-5 h-5" />, title: "Top Quality", desc: "Curated premium brands" },
                    { icon: <Sparkles className="w-5 h-5" />, title: "Daily Deals", desc: "Up to 30% off weekly" }
                ].map((feature, idx) => (
                    <motion.div 
                      key={idx}
                      initial={{ opacity: 0, y: 10 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      className="flex items-center space-x-4 p-4 rounded-xl hover:bg-gray-50 transition-colors"
                    >
                        <div className="w-10 h-10 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center flex-shrink-0">
                            {feature.icon}
                        </div>
                        <div>
                            <h4 className="text-sm font-bold text-gray-900">{feature.title}</h4>
                            <p className="text-xs text-gray-500">{feature.desc}</p>
                        </div>
                    </motion.div>
                ))}
            </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Shop by Category</h2>
            <p className="text-gray-500 max-w-2xl mx-auto">
              Explore our curated collections across sneakers, electronics, and fashion essentials.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {categories.map((cat) => (
              <div key={cat.name}>
                <CategoryCard {...cat} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-4">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">New Arrivals</h2>
              <p className="text-gray-500">The freshest drops and latest technology, straight to your doorstep.</p>
            </div>
            <div className="flex bg-gray-100 p-1 rounded-xl">
               <button className="px-6 py-2 bg-white text-gray-900 font-bold rounded-lg shadow-sm">Sneakers</button>
               <button className="px-6 py-2 text-gray-500 font-medium rounded-lg hover:text-gray-900 transition-colors">Tech</button>
               <button className="px-6 py-2 text-gray-500 font-medium rounded-lg hover:text-gray-900 transition-colors">Style</button>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredProducts.map((product) => (
              <div key={product.id}>
                <ProductCard product={product} />
              </div>
            ))}
          </div>
          <div className="mt-16 text-center">
             <button className="px-12 py-4 border-2 border-gray-900 text-gray-900 font-bold rounded-xl hover:bg-gray-900 hover:text-white transition-all">
                View All Products
             </button>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-orange-600" />
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_center,_white_1px,_transparent_0)] bg-[length:20px_20px]" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
             <h2 className="text-4xl font-bold mb-6">Join the EasyMart Club</h2>
             <p className="text-orange-100 mb-10 max-w-xl mx-auto text-lg leading-relaxed">
               Subscribe to receive early access to drops, exclusive discounts, and fashion inspiration curated for you.
             </p>
             <form className="max-w-md mx-auto flex gap-2">
                <input 
                  type="email" 
                  placeholder="Enter your email" 
                  className="flex-1 px-6 py-4 rounded-xl bg-white text-gray-900 font-medium focus:ring-2 focus:ring-orange-300 outline-none"
                />
                <button className="px-8 py-4 bg-gray-900 text-white font-bold rounded-xl hover:bg-black transition-all">
                  Join
                </button>
             </form>
        </div>
      </section>
    </main>
  );
}
