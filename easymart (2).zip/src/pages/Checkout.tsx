import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useCart } from '../context/CartContext';
import { formatPrice } from '../lib/utils';
import { ArrowLeft, CheckCircle2, CreditCard, ExternalLink, ShieldCheck, Mail, MapPin, Hash } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Checkout() {
  const { cart, totalPrice, clearCart } = useCart();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    city: '',
    zipCode: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    const productNames = cart.map(item => `${item.name} (x${item.quantity})`).join(', ');

    const payload = {
      name: formData.name,
      phone: formData.phone,
      email: formData.email,
      address: `${formData.address}, ${formData.city}, ${formData.zipCode}`,
      product: productNames,
      price: (totalPrice * 1.08).toFixed(2)
    };

    try {
      await fetch('https://script.google.com/macros/s/AKfycbxFawJXpAaSIQ2gQ-WmwDOIwpXEutrDVhGx1ZWLbRLBthlcyrZRPm8TAMJqDiyP4kXpzA/exec', {
        method: 'POST',
        mode: 'no-cors', 
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });
      
      setLoading(false);
      setSuccess(true);
      clearCart();
    } catch (error) {
      console.error('Error submitting order:', error);
      setLoading(false);
      setSuccess(true);
      clearCart();
    }
  };

  if (success) {
    return (
      <main className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md w-full bg-white p-10 rounded-3xl shadow-xl text-center"
        >
          <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-8">
            <CheckCircle2 className="w-10 h-10" />
          </div>
          <h2 className="text-3xl font-black text-gray-900 mb-4">Order Confirmed!</h2>
          <p className="text-gray-500 mb-8 leading-relaxed">
            Thank you, <strong>{formData.name}</strong>. Your order data has been sent and we'll be in touch soon.
          </p>
          <Link
            to="/"
            className="block w-full py-4 bg-orange-600 text-white rounded-xl font-bold hover:bg-orange-700 transition-all shadow-lg shadow-orange-600/30"
          >
            Return to Store
          </Link>
        </motion.div>
      </main>
    );
  }

  return (
    <main className="py-12 md:py-24 bg-gray-50/50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Link to="/cart" className="inline-flex items-center text-sm font-medium text-gray-500 hover:text-orange-600 mb-12 transition-colors">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Cart
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          {/* Main Checkout Form */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-white p-8 md:p-12 rounded-3xl shadow-sm border border-gray-100"
          >
            <div className="mb-10">
              <h2 className="text-3xl font-black text-gray-900 mb-2">Checkout</h2>
              <p className="text-gray-500">Please provide your details to complete your order.</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Name Section */}
              <div className="space-y-2">
                <label className="text-xs font-black text-gray-900 uppercase tracking-widest">Full Name</label>
                <input 
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required 
                  placeholder="John Doe" 
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-orange-500 focus:bg-white outline-none transition-all font-medium" 
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {/* Phone Section */}
                <div className="space-y-2">
                  <label className="text-xs font-black text-gray-900 uppercase tracking-widest">Phone Number</label>
                  <input 
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    required 
                    type="tel"
                    placeholder="017XXXXXXXX" 
                    className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-orange-500 focus:bg-white outline-none transition-all font-medium" 
                  />
                </div>
                {/* Email Section */}
                <div className="space-y-2">
                  <label className="text-xs font-black text-gray-900 uppercase tracking-widest">Email Address</label>
                  <input 
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required 
                    type="email" 
                    placeholder="name@example.com" 
                    className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-orange-500 focus:bg-white outline-none transition-all font-medium" 
                  />
                </div>
              </div>

              {/* Address Section */}
              <div className="space-y-2">
                <div className="flex items-center gap-2 mb-1">
                  <MapPin className="w-4 h-4 text-orange-600" />
                  <label className="text-xs font-black text-gray-900 uppercase tracking-widest">Shipping Address</label>
                </div>
                <textarea 
                  name="address"
                  value={formData.address}
                  onChange={handleChange}
                  required 
                  rows={2}
                  placeholder="Street Name, House No, Area" 
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-orange-500 focus:bg-white outline-none transition-all font-medium" 
                />
              </div>

              {/* City & ZIP */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-black text-gray-900 uppercase tracking-widest">City</label>
                  <input 
                    name="city"
                    value={formData.city}
                    onChange={handleChange}
                    required 
                    placeholder="City Name" 
                    className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-orange-500 focus:bg-white outline-none transition-all font-medium" 
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 mb-1">
                    <Hash className="w-4 h-4 text-orange-600" />
                    <label className="text-xs font-black text-gray-900 uppercase tracking-widest">ZIP Code</label>
                  </div>
                  <input 
                    name="zipCode"
                    value={formData.zipCode}
                    onChange={handleChange}
                    required 
                    placeholder="10001" 
                    className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-orange-500 focus:bg-white outline-none transition-all font-medium" 
                  />
                </div>
              </div>

              {/* Payment Method Display */}
              <div className="pt-6 border-t border-gray-100">
                <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-4">Payment Method</p>
                <div className="p-5 rounded-2xl border-2 border-orange-500 bg-orange-50 flex items-center justify-between shadow-sm">
                    <div className="flex items-center gap-4">
                        <CreditCard className="w-6 h-6 text-orange-600" />
                        <div>
                            <p className="font-bold text-sm text-gray-900">Secure Checkout</p>
                            <p className="text-xs text-gray-500">Fast & Verified Transaction</p>
                        </div>
                    </div>
                    <CheckCircle2 className="w-6 h-6 text-orange-600" />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading || cart.length === 0}
                className="w-full py-5 bg-gray-900 text-white rounded-2xl font-black flex items-center justify-center gap-3 hover:bg-orange-600 transition-all shadow-xl shadow-black/5 disabled:opacity-50 disabled:cursor-not-allowed h-16 mt-8 active:scale-[0.98]"
              >
                {loading ? (
                    <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                    <>
                        <ShieldCheck className="w-6 h-6" />
                        Complete Order
                    </>
                )}
              </button>
            </form>
          </motion.div>

          {/* Cart Highlights / Summary */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-8 lg:sticky lg:top-24"
          >
            <div className="bg-gray-900 text-white p-8 rounded-[2rem] shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/10 blur-3xl rounded-full -mr-16 -mt-16" />
                
                <h3 className="text-xl font-black mb-8 flex items-center gap-3">
                  Summary
                  <span className="px-2 py-0.5 bg-orange-500 text-[10px] rounded uppercase">{cart.length} items</span>
                </h3>
                
                <div className="space-y-5 max-h-72 overflow-y-auto pr-2 mb-8 scrollbar-hide">
                    {cart.map(item => (
                        <div key={item.id} className="flex justify-between items-center bg-white/5 p-4 rounded-2xl border border-white/5">
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 rounded-xl overflow-hidden bg-white/10 flex-shrink-0">
                                    <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                                </div>
                                <div className="max-w-[120px]">
                                    <p className="font-bold text-xs truncate">{item.name}</p>
                                    <p className="text-[10px] text-white/40">Quantity: {item.quantity}</p>
                                </div>
                            </div>
                            <p className="font-black text-sm text-orange-400">{formatPrice(item.price * item.quantity)}</p>
                        </div>
                    ))}
                </div>
                
                <div className="pt-6 border-t border-white/10">
                     <div className="flex justify-between items-center mb-2 text-white/50 text-xs">
                        <span>Items Subtotal</span>
                        <span>{formatPrice(totalPrice)}</span>
                     </div>
                     <div className="flex justify-between items-center mb-6 text-white/50 text-xs">
                        <span>Tax (8%)</span>
                        <span>{formatPrice(totalPrice * 0.08)}</span>
                     </div>
                     <div className="flex justify-between items-center">
                        <span className="font-bold text-white/50">Total Amount</span>
                        <span className="text-3xl font-black text-white">{formatPrice(totalPrice * 1.08)}</span>
                     </div>
                </div>
            </div>

            {/* Trust Badges */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white p-4 rounded-2xl border border-gray-100 flex flex-col items-center text-center shadow-sm">
                <ShieldCheck className="w-6 h-6 text-green-500 mb-2" />
                <p className="text-[10px] font-bold text-gray-900">Secure SSL</p>
              </div>
              <div className="bg-white p-4 rounded-2xl border border-gray-100 flex flex-col items-center text-center shadow-sm">
                <ExternalLink className="w-6 h-6 text-orange-500 mb-2" />
                <p className="text-[10px] font-bold text-gray-900">Direct Connect</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </main>
  );
}
