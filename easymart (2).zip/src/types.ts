export type Category = 'Sneakers' | 'Electronics' | 'Fashion';

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: Category;
  image: string;
  features?: string[];
  stock: number;
}

export interface CartItem extends Product {
  quantity: number;
}
