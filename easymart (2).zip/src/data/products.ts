import { Product } from '../types';

export const products: Product[] = [
  // SNEAKERS
  {
    id: 's1',
    name: 'Velocity Elite X1',
    description: 'High-performance running shoes with responsive cushioning and breathable mesh for maximum comfort and speed.',
    price: 159.99,
    category: 'Sneakers',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800',
    stock: 12,
    features: ['React Foam tech', 'Breathable mesh', 'Carbon fiber plate']
  },
  {
    id: 's2',
    name: 'Urban Street Pro',
    description: 'Classic streetwear sneakers with a modern twist. Premium leather and durable rubber outsole.',
    price: 119.99,
    category: 'Sneakers',
    image: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&q=80&w=800',
    stock: 8,
    features: ['Full-grain leather', 'Vintage design', 'Padded collar']
  },
  {
    id: 's3',
    name: 'AeroMax 270',
    description: 'Iconic chunky silhouette with a massive air unit in the heel for unparalleled comfort and style.',
    price: 145.00,
    category: 'Sneakers',
    image: 'https://images.unsplash.com/photo-1552346154-21d32810abb1?auto=format&fit=crop&q=80&w=800',
    stock: 15,
    features: ['Visible Air unit', 'Lightweight construction', 'Bold colorways']
  },
  {
    id: 's4',
    name: 'Court Legend Low',
    description: 'Minimalist court shoes inspired by 80s basketball classics. Versatile for any outfit.',
    price: 89.99,
    category: 'Sneakers',
    image: 'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?auto=format&fit=crop&q=80&w=800',
    stock: 20,
    features: ['Durable canvas', 'Low-profile', 'Eco-friendly materials']
  },
  {
    id: 's5',
    name: 'Trail Blazer GORE-TEX',
    description: 'Waterproof hiking sneakers designed to tackle the toughest terrains in style.',
    price: 179.99,
    category: 'Sneakers',
    image: 'https://images.unsplash.com/photo-1539185441755-769473a23570?auto=format&fit=crop&q=80&w=800',
    stock: 5,
    features: ['GTX Lining', 'Vibram Outsole', 'Quick-lace system']
  },
  {
    id: 's6',
    name: 'Cloud Walker Z',
    description: 'Ultra-lightweight walking shoes that feel like you are walking on air.',
    price: 95.00,
    category: 'Sneakers',
    image: 'https://images.unsplash.com/photo-1460353581641-37baddab0fa2?auto=format&fit=crop&q=80&w=800',
    stock: 25,
    features: ['Memory foam insole', 'Flexible sole', 'Slip-on design']
  },
  {
    id: 's7',
    name: 'Neon Flash Racer',
    description: 'Vibrant, high-visibility sneakers for night runners and style enthusiasts alike.',
    price: 130.00,
    category: 'Sneakers',
    image: 'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&q=80&w=800',
    stock: 10,
    features: ['Reflective panels', 'Glow-in-the-dark sole', '3D printed upper']
  },
  {
    id: 's8',
    name: 'Retro Hoopster High',
    description: 'High-top basketball sneakers with an old-school soul and new-school comfort.',
    price: 125.00,
    category: 'Sneakers',
    image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&q=80&w=800',
    stock: 14,
    features: ['Ankle support', 'Perforated toe box', 'Classic branding']
  },
  {
    id: 's9',
    name: 'Minimalist Drift',
    description: 'The ultimate clean-cut sneaker for the modern professional. Less is more.',
    price: 110.00,
    category: 'Sneakers',
    image: 'https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&q=80&w=800',
    stock: 18,
    features: ['Soft suede', 'Monochromatic', 'Sustainable rubber']
  },
  {
    id: 's10',
    name: 'Cyber Runner 2077',
    description: 'Futuristic design meets extreme performance. A glimpse into the future of footwear.',
    price: 199.99,
    category: 'Sneakers',
    image: 'https://images.unsplash.com/photo-1512374382149-4332c6c0240x?auto=format&fit=crop&q=80&w=800', // Fallback
    stock: 6,
    features: ['Holographic accents', 'Smart-lace tech', 'Shock absorption']
  },

  // ELECTRONICS
  {
    id: 'e1',
    name: 'SonicWave ANC Headphones',
    description: 'Premium noise-canceling headphones with 40-hour battery life and studio-grade sound.',
    price: 299.99,
    category: 'Electronics',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80&w=800',
    stock: 20,
    features: ['Active Noise Canceling', 'Hi-Res Audio', 'Multipoint Connection']
  },
  {
    id: 'e2',
    name: 'Lumina Smartwatch Series 5',
    description: 'The ultimate health and fitness companion. Track your heart rate, sleep, and workouts with precision.',
    price: 249.00,
    category: 'Electronics',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=800',
    stock: 15,
    features: ['ECG App', 'Always-On Display', 'Water resistant 50m']
  },
  {
    id: 'e3',
    name: 'VoltCharge Pad Pro',
    description: 'Triple-device wireless charging station. Clean up your desk and power up your life.',
    price: 69.99,
    category: 'Electronics',
    image: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&q=80&w=800',
    stock: 30,
    features: ['Fast charging', 'MagSafe compatible', 'Heat dissipation']
  },

  // FASHION
  {
    id: 'f1',
    name: 'Essential Oversized Hoodie',
    description: 'Ultra-soft heavyweight cotton hoodie for the perfect casual look.',
    price: 65.00,
    category: 'Fashion',
    image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&q=80&w=800',
    stock: 40,
    features: ['100% Cotton', 'Brushed interior', 'Relaxed fit']
  },
  {
    id: 'f2',
    name: 'Vanguard Bomber Jacket',
    description: 'Modern flight jacket with water-resistant shell and quilted lining.',
    price: 120.00,
    category: 'Fashion',
    image: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&q=80&w=800',
    stock: 12,
    features: ['Flight nylon', 'Utility pocket', 'Slim fit']
  }
];
